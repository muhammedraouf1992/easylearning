<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin_master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin_master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <div class="content-body" style="min-height: 788px;">
                <div class="container-fluid">
                    <!-- Add Project -->
                    <div class="modal fade" id="addProjectSidebar">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
    
    
                                </div>
                                <div class="modal-body">
    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row page-titles mx-0">
                        <div class="col-sm-6 p-md-0">
                            <div class="welcome-text">
    
    
                            </div>
                        </div>
                        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
    
                        </div>
                    </div>
                    <!-- row -->
    
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Service Page </h4>
                                </div>
                                <div class="card-body">
        <div class="table-responsive">
            <table class="table table-responsive-md">
                <thead>
                    <tr>
    
    
                        <th><strong>Project Name </strong></th>
                        <th><strong>Project Description</strong></th>
                        <th><strong>Project features</strong></th>
                        <th><strong>Project Logo</strong></th>
    
                        <th></th>
                    </tr>
                </thead>
                <tbody>
    
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>								 
        <tr>
    
    
            <td> <?php echo e($item->project_name); ?>  </td>
            <td><?php echo e(Str::limit($item->project_description, 15, '..')); ?> </td>
            <td><?php echo e(Str::limit($item->project_features, 15, '..')); ?> </td>
            <td> <img src="<?php echo e(asset($item->image_one)); ?>" style="width: 70px; height: 40px;"> </td>
    
              <td>
                    <div class="d-flex">
         <a href="<?php echo e(route('editProject',$item->id)); ?>" class="btn btn-primary shadow btn-xs sharp mr-1"><i class="fa fa-pencil"></i></a>
                    
                        <form action="<?php echo e(route('deleteProject',$item->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></button>
                        </form>
                    
         
                    </div>
                </td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
    
    
    
    
    
    
    
                        </div>
                    </div>
                </div>
            </div>
    
    
    
    
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\Users\logec\Desktop\backend\easylearning\rapi\resources\views/admin/backend/projects/index.blade.php ENDPATH**/ ?>