<div class="footer">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="http://dexignzone.com/" target="_blank">Raouf</a> 2021</p>
    </div>
</div><?php /**PATH C:\Users\logec\Desktop\backend\easylearning\rapi\resources\views/admin/body/footer.blade.php ENDPATH**/ ?>